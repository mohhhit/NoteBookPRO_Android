import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../services/api_service.dart';
// import '../services/firebase_service.dart'; // Uncomment when ready to use Firebase

class AppState extends ChangeNotifier {
  final ApiService _apiService = ApiService();
  // final FirebaseService _firebaseService = FirebaseService(); // Uncomment when ready
  
  // Current state
  List<Space> _spaces = [];
  Space? _currentSpace;
  List<ChatInfo> _chats = [];
  Chat? _currentChat;
  List<Map<String, dynamic>> _uploadedFiles = [];
  String _activeTool = 'Chat';
  bool _isLoading = false;
  String? _error;
  String? _successMessage;
  bool _isUploading = false;
  bool _isThinking = false;
  
  // UI state
  bool _sidebarOpen = true;
  bool _plusMenuOpen = false;
  bool _toolsMenuOpen = false;
  bool _filesDrawerOpen = false;
  
  // Getters
  List<Space> get spaces => _spaces;
  Space? get currentSpace => _currentSpace;
  List<ChatInfo> get chats => _chats;
  Chat? get currentChat => _currentChat;
  List<Map<String, dynamic>> get uploadedFiles => _uploadedFiles;
  String get activeTool => _activeTool;
  bool get isLoading => _isLoading;
  String? get error => _error;
  String? get successMessage => _successMessage;
  bool get isUploading => _isUploading;
  bool get isThinking => _isThinking;
  bool get sidebarOpen => _sidebarOpen;
  bool get plusMenuOpen => _plusMenuOpen;
  bool get toolsMenuOpen => _toolsMenuOpen;
  bool get filesDrawerOpen => _filesDrawerOpen;
  
  // ==================== Initialization ====================
  
  Future<void> initialize() async {
    _setLoading(true);
    try {
      await loadSpaces();
      if (_spaces.isNotEmpty) {
        await selectSpace(_spaces.first.id);
      }
    } catch (e) {
      _setError(e.toString());
    } finally {
      _setLoading(false);
    }
  }
  
  // ==================== Spaces ====================
  
  Future<void> loadSpaces() async {
    try {
      _spaces = await _apiService.getSpaces();
      notifyListeners();
    } catch (e) {
      _setError('Failed to load spaces: $e');
    }
  }
  
  Future<void> createSpace(String name) async {
    _setLoading(true);
    try {
      final space = await _apiService.createSpace(name);
      _spaces.add(space);
      await selectSpace(space.id);
    } catch (e) {
      _setError('Failed to create space: $e');
    } finally {
      _setLoading(false);
    }
  }
  
  Future<void> selectSpace(String spaceId) async {
    _currentSpace = _spaces.firstWhere((s) => s.id == spaceId);
    _currentChat = null;
    await loadChats();
    await loadUploadedFiles();
    notifyListeners();
  }
  
  Future<void> deleteSpace(String spaceId) async {
    try {
      await _apiService.deleteSpace(spaceId);
      _spaces.removeWhere((s) => s.id == spaceId);
      if (_currentSpace?.id == spaceId) {
        _currentSpace = _spaces.isNotEmpty ? _spaces.first : null;
        if (_currentSpace != null) {
          await selectSpace(_currentSpace!.id);
        }
      }
      notifyListeners();
    } catch (e) {
      _setError('Failed to delete space: $e');
    }
  }
  
  // ==================== Chats ====================
  
  Future<void> loadChats() async {
    if (_currentSpace == null) return;
    
    try {
      _chats = await _apiService.getChats(_currentSpace!.id);
      notifyListeners();
    } catch (e) {
      _setError('Failed to load chats: $e');
    }
  }
  
  Future<void> loadChat(String chatId) async {
    if (_currentSpace == null) return;
    
    try {
      _currentChat = await _apiService.getChat(_currentSpace!.id, chatId);
      notifyListeners();
    } catch (e) {
      _setError('Failed to load chat: $e');
    }
  }
  
  Future<void> newChat() async {
    _currentChat = null;
    notifyListeners();
  }
  
  Future<void> deleteChat(String chatId) async {
    if (_currentSpace == null) return;
    
    try {
      await _apiService.deleteChat(_currentSpace!.id, chatId);
      _chats.removeWhere((c) => c.id == chatId);
      if (_currentChat?.id == chatId) {
        _currentChat = null;
      }
      notifyListeners();
    } catch (e) {
      _setError('Failed to delete chat: $e');
    }
  }
  
  // ==================== Messaging ====================
  
  Future<void> sendMessage(String query) async {
    if (_currentSpace == null) return;
    
    _setLoading(true);
    _isThinking = true;
    notifyListeners();
    
    try {
      // Add user message to UI immediately
      if (_currentChat == null) {
        _currentChat = Chat(
          id: '',
          messages: [],
          createdAt: DateTime.now().toIso8601String(),
          updatedAt: DateTime.now().toIso8601String(),
        );
      }
      
      _currentChat!.messages.add(ChatMessage(
        role: 'user',
        content: query,
        timestamp: DateTime.now().toIso8601String(),
      ));
      notifyListeners();
      
      // Send to API
      final response = await _apiService.sendMessage(
        query: query,
        spaceId: _currentSpace!.id,
        chatId: _currentChat?.id.isEmpty == true ? null : _currentChat?.id,
        workflow: _activeTool.toLowerCase(),
      );
      
      // Update chat with response
      _currentChat = Chat(
        id: response.chatId,
        messages: _currentChat!.messages
          ..add(ChatMessage(
            role: 'assistant',
            content: response.response,
            timestamp: response.timestamp,
          )),
        createdAt: _currentChat!.createdAt,
        updatedAt: response.timestamp,
      );
      
      // Reload chats list
      await loadChats();
      _isThinking = false;
      notifyListeners();
    } catch (e) {
      _isThinking = false;
      _setError('Failed to send message: $e');
    } finally {
      _setLoading(false);
    }
  }
  
  // ==================== File Upload ====================
  
  Future<void> loadUploadedFiles() async {
    if (_currentSpace == null) return;
    
    try {
      _uploadedFiles = await _apiService.getUploadedFiles(_currentSpace!.id);
      notifyListeners();
    } catch (e) {
      // Silently fail - files list is non-critical
      _uploadedFiles = [];
    }
  }
  
  Future<void> uploadFiles(List<PlatformFile> files) async {
    if (_currentSpace == null) return;
    
    _isUploading = true;
    _successMessage = null;
    _error = null;
    notifyListeners();
    
    try {
      final result = await _apiService.uploadFiles(_currentSpace!.id, files);
      _successMessage = '✅ Successfully uploaded ${result['files_processed']} files (${result['total_chunks']} chunks processed)';
      await loadSpaces(); // Refresh file count
      await loadUploadedFiles(); // Refresh files list
      notifyListeners();
      
      // Auto-dismiss success message after 5 seconds
      Future.delayed(const Duration(seconds: 5), () {
        if (_successMessage != null) {
          _successMessage = null;
          notifyListeners();
        }
      });
    } catch (e) {
      _setError('❌ Failed to upload files: $e');
    } finally {
      _isUploading = false;
      notifyListeners();
    }
  }
  
  // ==================== Tools ====================
  
  void setActiveTool(String tool) {
    _activeTool = tool;
    _toolsMenuOpen = false;
    notifyListeners();
  }
  
  // ==================== UI State ====================
  
  void toggleSidebar() {
    _sidebarOpen = !_sidebarOpen;
    notifyListeners();
  }
  
  void togglePlusMenu() {
    _plusMenuOpen = !_plusMenuOpen;
    _toolsMenuOpen = false;
    notifyListeners();
  }
  
  void toggleToolsMenu() {
    _toolsMenuOpen = !_toolsMenuOpen;
    _plusMenuOpen = false;
    notifyListeners();
  }
  
  void toggleFilesDrawer() {
    _filesDrawerOpen = !_filesDrawerOpen;
    notifyListeners();
  }
  
  void closeMenus() {
    _plusMenuOpen = false;
    _toolsMenuOpen = false;
    notifyListeners();
  }
  
  // ==================== Helpers ====================
  
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }
  
  void _setError(String? error) {
    _error = error;
    notifyListeners();
  }
  
  void clearError() {
    _error = null;
    notifyListeners();
  }
  
  void clearSuccessMessage() {
    _successMessage = null;
    notifyListeners();
  }
}
