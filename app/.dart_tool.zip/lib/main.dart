import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:provider/provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'providers/app_state.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Firebase
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  
  // Connect to Firebase emulators in debug mode (optional - for local testing)
  // Uncomment when you run: firebase emulators:start
  // if (kDebugMode) {
  //   FirebaseFunctions.instance.useFunctionsEmulator('localhost', 5001);
  //   FirebaseFirestore.instance.useFirestoreEmulator('localhost', 8080);
  //   FirebaseStorage.instance.useStorageEmulator('localhost', 9199);
  // }
  
  runApp(
    ChangeNotifierProvider(
      create: (_) => AppState()..initialize(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NotebookPRO',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0D0D0D),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF8AB4F8),
          surface: Color(0xFF1E1E1E),
          background: Color(0xFF0D0D0D),
        ),
        fontFamily: 'Google Sans',
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(
      builder: (context, appState, _) {
        return Scaffold(
          body: GestureDetector(
            onTap: () => appState.closeMenus(),
            child: Row(
              children: [
                // Sidebar
                if (appState.sidebarOpen)
                  Container(
                    width: 260,
                    decoration: const BoxDecoration(
                      color: Color(0xFF131314),
                      border: Border(
                        right: BorderSide(color: Color(0xFF2D2D2D)),
                      ),
                    ),
                    child: _buildSidebar(appState),
                  ),
                
                // Main content
                Expanded(
                  child: Stack(
                    children: [
                      Column(
                        children: [
                          // Top bar
                          _buildTopBar(appState),
                          
                          // Chat area
                          Expanded(
                            child: appState.currentChat == null
                                ? _buildWelcomeScreen(appState)
                                : _buildChatMessages(appState),
                          ),
                          
                          // Input area
                          _buildInputArea(appState),
                        ],
                      ),
                      
                      // Plus menu popup
                      if (appState.plusMenuOpen)
                        Positioned(
                          bottom: 80,
                          left: MediaQuery.of(context).size.width / 2 - 100,
                          child: _buildPlusMenu(appState),
                        ),
                      
                      // Tools menu popup
                      if (appState.toolsMenuOpen)
                        Positioned(
                          bottom: 80,
                          right: 24,
                          child: _buildToolsMenu(appState),
                        ),
                      
                      // Error snackbar
                      if (appState.error != null)
                        Positioned(
                          top: 16,
                          left: 16,
                          right: 16,
                          child: Material(
                            color: Colors.red.shade900,
                            borderRadius: BorderRadius.circular(12),
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Row(
                                children: [
                                  const Icon(Icons.error, color: Colors.white),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      appState.error!,
                                      style: const TextStyle(color: Colors.white),
                                    ),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.close, color: Colors.white),
                                    onPressed: () => appState.clearError(),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      
                      // Success message banner
                      if (appState.successMessage != null)
                        Positioned(
                          top: 16,
                          left: 16,
                          right: 16,
                          child: Material(
                            color: Colors.green.shade800,
                            borderRadius: BorderRadius.circular(12),
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Row(
                                children: [
                                  const Icon(Icons.check_circle, color: Colors.white),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      appState.successMessage!,
                                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
                                    ),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.close, color: Colors.white),
                                    onPressed: () => appState.clearSuccessMessage(),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      
                      // Upload loading overlay
                      if (appState.isUploading)
                        Positioned.fill(
                          child: Container(
                            color: Colors.black87,
                            child: Center(
                              child: Card(
                                color: const Color(0xFF2D2D2D),
                                child: Container(
                                  width: 400,
                                  padding: const EdgeInsets.all(32),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const CircularProgressIndicator(
                                        valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF8AB4F8)),
                                        strokeWidth: 3,
                                      ),
                                      const SizedBox(height: 24),
                                      const Text(
                                        'Processing Documents',
                                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                                      ),
                                      const SizedBox(height: 16),
                                      
                                      // Progress bar
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(4),
                                        child: LinearProgressIndicator(
                                          backgroundColor: const Color(0xFF1A1A1A),
                                          valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF8AB4F8)),
                                          minHeight: 6,
                                        ),
                                      ),
                                      
                                      const SizedBox(height: 20),
                                      
                                      // Status steps
                                      _buildProcessingStep('📤', 'Uploading files', true),
                                      const SizedBox(height: 8),
                                      _buildProcessingStep('📄', 'Extracting text content', true),
                                      const SizedBox(height: 8),
                                      _buildProcessingStep('✂️', 'Chunking documents', true),
                                      const SizedBox(height: 8),
                                      _buildProcessingStep('🧠', 'Generating embeddings', true),
                                      const SizedBox(height: 8),
                                      _buildProcessingStep('💾', 'Storing in vector database', true),
                                      
                                      const SizedBox(height: 16),
                                      Text(
                                        'This may take a few moments...',
                                        style: TextStyle(fontSize: 13, color: Colors.grey.shade500, fontStyle: FontStyle.italic),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      
                      // Files drawer (slides from right)
                      if (appState.filesDrawerOpen)
                        Positioned(
                          right: 0,
                          top: 0,
                          bottom: 0,
                          child: _buildFilesDrawer(appState),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildSidebar(AppState appState) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Logo and new chat
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF4285F4), Color(0xFFEA4335), Color(0xFFFBBC05), Color(0xFF34A853)],
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.auto_awesome, size: 20),
              ),
              const SizedBox(width: 12),
              const Text(
                'NotebookPRO',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
        
        // New Chat button
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: ElevatedButton.icon(
            onPressed: () => appState.newChat(),
            icon: const Icon(Icons.add, size: 18),
            label: const Text('New Chat'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              foregroundColor: const Color(0xFFE8EAED),
              side: const BorderSide(color: Color(0xFF3C4043)),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              minimumSize: const Size(double.infinity, 40),
            ),
          ),
        ),
        
        const SizedBox(height: 16),
        
        // Spaces
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Text(
            'SPACES',
            style: TextStyle(fontSize: 11, color: Color(0xFF9AA0A6), fontWeight: FontWeight.w600),
          ),
        ),
        
        ...appState.spaces.map((space) => ListTile(
          leading: Stack(
            clipBehavior: Clip.none,
            children: [
              const Icon(Icons.folder, size: 20),
              if (space.fileCount > 0)
                Positioned(
                  right: -6,
                  top: -6,
                  child: Container(
                    padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      color: const Color(0xFF8AB4F8),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    constraints: const BoxConstraints(
                      minWidth: 16,
                      minHeight: 16,
                    ),
                    child: Text(
                      space.fileCount.toString(),
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          ),
          title: Text(space.name, style: const TextStyle(fontSize: 14)),
          subtitle: Text(
            '${space.fileCount} file${space.fileCount != 1 ? 's' : ''}', 
            style: const TextStyle(fontSize: 11, color: Color(0xFF9AA0A6)),
          ),
          selected: appState.currentSpace?.id == space.id,
          selectedTileColor: const Color(0xFF1E3A5F),
          onTap: () => appState.selectSpace(space.id),
          trailing: IconButton(
            icon: const Icon(Icons.delete, size: 18),
            onPressed: () => appState.deleteSpace(space.id),
          ),
        )),
        
        // Add space button
        Padding(
          padding: const EdgeInsets.all(12),
          child: OutlinedButton.icon(
            onPressed: () => _showCreateSpaceDialog(appState),
            icon: const Icon(Icons.add, size: 18),
            label: const Text('New Space'),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size(double.infinity, 40),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            ),
          ),
        ),
        
        const Divider(color: Color(0xFF2D2D2D)),
        
        // Chats for current space
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Text(
            appState.currentSpace != null 
                ? '${appState.currentSpace!.name.toUpperCase()} CHATS'
                : 'CHATS',
            style: const TextStyle(fontSize: 11, color: Color(0xFF9AA0A6), fontWeight: FontWeight.w600),
          ),
        ),
        
        Expanded(
          child: appState.chats.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Text(
                      'No chats yet\nStart a conversation!',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Color(0xFF9AA0A6), fontSize: 13),
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: appState.chats.length,
                  itemBuilder: (context, index) {
                    final chat = appState.chats[index];
                    return ListTile(
                      leading: const Icon(Icons.chat_bubble_outline, size: 18),
                      title: Text(
                        chat.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 13),
                      ),
                      onTap: () => appState.loadChat(chat.id),
                      selected: appState.currentChat?.id == chat.id,
                      selectedTileColor: const Color(0xFF1E3A5F),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, size: 16),
                        onPressed: () => appState.deleteChat(chat.id),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildTopBar(AppState appState) {
    final fileCount = appState.uploadedFiles.length;
    
    return Container(
      height: 60,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Color(0xFF2D2D2D))),
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () => appState.toggleSidebar(),
          ),
          const Spacer(),
          Text(
            appState.currentSpace?.name ?? 'No Space Selected',
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
          ),
          const Spacer(),
          
          // Files button with badge
          if (fileCount > 0)
            Stack(
              clipBehavior: Clip.none,
              children: [
                IconButton(
                  icon: const Icon(Icons.description),
                  tooltip: 'View uploaded files',
                  onPressed: () => appState.toggleFilesDrawer(),
                ),
                Positioned(
                  right: 6,
                  top: 6,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: const Color(0xFF8AB4F8),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    constraints: const BoxConstraints(
                      minWidth: 18,
                      minHeight: 18,
                    ),
                    child: Text(
                      fileCount.toString(),
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ],
            ),
          
          // Upload button
          IconButton(
            icon: const Icon(Icons.upload_file),
            tooltip: 'Upload files',
            onPressed: () => _uploadFiles(appState),
          ),
        ],
      ),
    );
  }

  Widget _buildWelcomeScreen(AppState appState) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF4285F4), Color(0xFFEA4335), Color(0xFFFBBC05), Color(0xFF34A853)],
              ),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Icon(Icons.auto_awesome, size: 40, color: Colors.white),
          ),
          const SizedBox(height: 24),
          const Text(
            'Hello!',
            style: TextStyle(fontSize: 32, fontWeight: FontWeight.w300),
          ),
          const SizedBox(height: 8),
          const Text(
            'How can I help you today?',
            style: TextStyle(fontSize: 16, color: Color(0xFF9AA0A6)),
          ),
        ],
      ),
    );
  }

  Widget _buildChatMessages(AppState appState) {
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    
    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.all(24),
      itemCount: appState.currentChat!.messages.length + (appState.isThinking ? 1 : 0),
      itemBuilder: (context, index) {
        // Show thinking indicator as last item
        if (index == appState.currentChat!.messages.length) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 24),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 16,
                  backgroundColor: const Color(0xFF1E3A5F),
                  child: Icon(
                    Icons.auto_awesome,
                    size: 18,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'NotebookPRO',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                          color: Color(0xFF9AA0A6),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF8AB4F8)),
                            ),
                          ),
                          const SizedBox(width: 12),
                          const Text(
                            'Thinking...',
                            style: TextStyle(
                              fontSize: 15,
                              height: 1.5,
                              color: Color(0xFF9AA0A6),
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }
        
        final message = appState.currentChat!.messages[index];
        final isUser = message.role == 'user';
        
        return Padding(
          padding: const EdgeInsets.only(bottom: 24),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 16,
                backgroundColor: isUser ? const Color(0xFF8AB4F8) : const Color(0xFF1E3A5F),
                child: Icon(
                  isUser ? Icons.person : Icons.auto_awesome,
                  size: 18,
                  color: Colors.white,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isUser ? 'You' : 'NotebookPRO',
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 13,
                        color: Color(0xFF9AA0A6),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      message.content,
                      style: const TextStyle(fontSize: 15, height: 1.5),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildInputArea(AppState appState) {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          // Plus button
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(24),
            ),
            child: IconButton(
              icon: const Icon(Icons.add_circle_outline, size: 28),
              onPressed: () => appState.togglePlusMenu(),
            ),
          ),
          
          const SizedBox(width: 12),
          
          // Input field
          Expanded(
            child: Container(
              constraints: const BoxConstraints(maxWidth: 720),
              decoration: BoxDecoration(
                color: const Color(0xFF1E1E1E),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: const Color(0xFF3C4043)),
              ),
              child: TextField(
                controller: _messageController,
                decoration: const InputDecoration(
                  hintText: 'Ask anything...',
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                ),
                onSubmitted: (value) {
                  if (value.trim().isNotEmpty) {
                    appState.sendMessage(value);
                    _messageController.clear();
                  }
                },
              ),
            ),
          ),
          
          const SizedBox(width: 12),
          
          // Tools button
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: const Color(0xFF3C4043)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 16),
                  child: Text(appState.activeTool, style: const TextStyle(fontSize: 13)),
                ),
                IconButton(
                  icon: const Icon(Icons.arrow_drop_down),
                  onPressed: () => appState.toggleToolsMenu(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlusMenu(AppState appState) {
    return Material(
      color: const Color(0xFF2D2D2D),
      borderRadius: BorderRadius.circular(12),
      elevation: 8,
      child: Container(
        width: 200,
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _menuItem(Icons.upload_file, 'Upload Files', () {
              appState.closeMenus();
              _uploadFiles(appState);
            }),
            _menuItem(Icons.add, 'New Space', () {
              appState.closeMenus();
              _showCreateSpaceDialog(appState);
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildToolsMenu(AppState appState) {
    return Material(
      color: const Color(0xFF2D2D2D),
      borderRadius: BorderRadius.circular(12),
      elevation: 8,
      child: Container(
        width: 160,
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _menuItem(Icons.chat, 'Chat', () => appState.setActiveTool('Chat'),
                selected: appState.activeTool == 'Chat'),
            _menuItem(Icons.summarize, 'Summarize', () => appState.setActiveTool('Summarize'),
                selected: appState.activeTool == 'Summarize'),
          ],
        ),
      ),
    );
  }

  Widget _menuItem(IconData icon, String label, VoidCallback onTap, {bool selected = false}) {
    return ListTile(
      dense: true,
      leading: Icon(icon, size: 20),
      title: Text(label, style: const TextStyle(fontSize: 14)),
      trailing: selected ? const Icon(Icons.check, size: 18) : null,
      onTap: onTap,
    );
  }

  Widget _buildProcessingStep(String emoji, String text, bool isActive) {
    return Row(
      children: [
        Text(emoji, style: const TextStyle(fontSize: 16)),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              fontSize: 14,
              color: isActive ? Colors.white : Colors.grey.shade600,
              fontWeight: isActive ? FontWeight.w500 : FontWeight.normal,
            ),
          ),
        ),
        if (isActive)
          Container(
            width: 16,
            height: 16,
            margin: const EdgeInsets.only(left: 8),
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(Colors.grey.shade400),
            ),
          ),
      ],
    );
  }

  Future<void> _uploadFiles(AppState appState) async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: ['pdf', 'txt', 'docx'],
      withData: true, // Important for web: loads file bytes
    );

    if (result != null && result.files.isNotEmpty) {
      await appState.uploadFiles(result.files);
    }
  }

  Future<void> _showCreateSpaceDialog(AppState appState) async {
    final controller = TextEditingController();
    
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF2D2D2D),
        title: const Text('Create New Space'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(
            hintText: 'Space name',
            border: OutlineInputBorder(),
          ),
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (controller.text.trim().isNotEmpty) {
                appState.createSpace(controller.text.trim());
                Navigator.pop(context);
              }
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }

  Widget _buildFilesDrawer(AppState appState) {
    return GestureDetector(
      onTap: () {}, // Prevent closing when tapping inside drawer
      child: Container(
        width: 320,
        decoration: const BoxDecoration(
          color: Color(0xFF1E1E1E),
          border: Border(left: BorderSide(color: Color(0xFF2D2D2D))),
          boxShadow: [
            BoxShadow(
              color: Colors.black45,
              blurRadius: 10,
              offset: Offset(-2, 0),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(
                border: Border(bottom: BorderSide(color: Color(0xFF2D2D2D))),
              ),
              child: Row(
                children: [
                  const Icon(Icons.description, color: Color(0xFF8AB4F8)),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text(
                      'Uploaded Files',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => appState.toggleFilesDrawer(),
                  ),
                ],
              ),
            ),
            
            // File count summary
            Container(
              padding: const EdgeInsets.all(16),
              color: const Color(0xFF131314),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E3A5F),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '${appState.uploadedFiles.length} files',
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF8AB4F8),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    'in ${appState.currentSpace?.name ?? "this space"}',
                    style: TextStyle(fontSize: 13, color: Colors.grey.shade400),
                  ),
                ],
              ),
            ),
            
            // Files list
            Expanded(
              child: appState.uploadedFiles.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.folder_open, size: 64, color: Colors.grey.shade700),
                          const SizedBox(height: 16),
                          Text(
                            'No files uploaded yet',
                            style: TextStyle(fontSize: 14, color: Colors.grey.shade500),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(8),
                      itemCount: appState.uploadedFiles.length,
                      itemBuilder: (context, index) {
                        final file = appState.uploadedFiles[index];
                        final filename = file['filename'] ?? 'Unknown';
                        final chunks = file['chunks'] ?? 0;
                        final processedAt = file['processed_at'] ?? '';
                        
                        // Determine file icon based on extension
                        IconData fileIcon = Icons.insert_drive_file;
                        Color fileColor = Colors.grey.shade400;
                        if (filename.endsWith('.pdf')) {
                          fileIcon = Icons.picture_as_pdf;
                          fileColor = Colors.red.shade400;
                        } else if (filename.endsWith('.docx') || filename.endsWith('.doc')) {
                          fileIcon = Icons.description;
                          fileColor = Colors.blue.shade400;
                        } else if (filename.endsWith('.txt')) {
                          fileIcon = Icons.text_snippet;
                          fileColor = Colors.green.shade400;
                        }
                        
                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          color: const Color(0xFF2D2D2D),
                          child: ListTile(
                            dense: true,
                            leading: Icon(fileIcon, color: fileColor, size: 24),
                            title: Text(
                              filename,
                              style: const TextStyle(fontSize: 13),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            subtitle: Text(
                              '$chunks chunks',
                              style: TextStyle(fontSize: 11, color: Colors.grey.shade500),
                            ),
                            trailing: Icon(
                              Icons.check_circle,
                              color: Colors.green.shade400,
                              size: 18,
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
