import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:file_picker/file_picker.dart';

class ApiService {
  // Change this to your backend URL
  static const String baseUrl = 'http://localhost:8000';
  
  // ==================== Spaces ====================
  
  Future<List<Space>> getSpaces() async {
    final response = await http.get(Uri.parse('$baseUrl/api/spaces'));
    
    if (response.statusCode == 200) {
      List<dynamic> data = json.decode(response.body);
      return data.map((json) => Space.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load spaces');
    }
  }
  
  Future<Space> createSpace(String name) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/spaces'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({'name': name}),
    );
    
    if (response.statusCode == 200) {
      return Space.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to create space');
    }
  }
  
  Future<void> deleteSpace(String spaceId) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/api/spaces/$spaceId'),
    );
    
    if (response.statusCode != 200) {
      throw Exception('Failed to delete space');
    }
  }
  
  // ==================== Chats ====================
  
  Future<List<ChatInfo>> getChats(String spaceId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/spaces/$spaceId/chats'),
    );
    
    if (response.statusCode == 200) {
      List<dynamic> data = json.decode(response.body);
      return data.map((json) => ChatInfo.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load chats');
    }
  }
  
  Future<Chat> getChat(String spaceId, String chatId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/spaces/$spaceId/chats/$chatId'),
    );
    
    if (response.statusCode == 200) {
      return Chat.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to load chat');
    }
  }
  
  Future<void> deleteChat(String spaceId, String chatId) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/api/spaces/$spaceId/chats/$chatId'),
    );
    
    if (response.statusCode != 200) {
      throw Exception('Failed to delete chat');
    }
  }
  
  // ==================== Chat/RAG ====================
  
  Future<ChatResponse> sendMessage({
    required String query,
    required String spaceId,
    String? chatId,
    String workflow = 'chat',
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/chat'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'query': query,
        'space_id': spaceId,
        'chat_id': chatId,
        'workflow': workflow,
      }),
    );
    
    if (response.statusCode == 200) {
      return ChatResponse.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to send message: ${response.body}');
    }
  }
  
  // ==================== File Upload ====================
  
  Future<Map<String, dynamic>> uploadFiles(String spaceId, List<PlatformFile> files) async {
    var request = http.MultipartRequest(
      'POST',
      Uri.parse('$baseUrl/api/spaces/$spaceId/upload'),
    );
    
    for (var file in files) {
      if (file.bytes != null) {
        // Web: use bytes
        request.files.add(http.MultipartFile.fromBytes(
          'files',
          file.bytes!,
          filename: file.name,
        ));
      } else if (file.path != null) {
        // Desktop: use path
        request.files.add(await http.MultipartFile.fromPath('files', file.path!));
      }
    }
    
    var streamedResponse = await request.send();
    var response = await http.Response.fromStream(streamedResponse);
    
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to upload files: ${response.body}');
    }
  }
  
  Future<List<Map<String, dynamic>>> getUploadedFiles(String spaceId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/spaces/$spaceId/files'),
    );
    
    if (response.statusCode == 200) {
      List<dynamic> data = json.decode(response.body);
      return data.cast<Map<String, dynamic>>();
    } else {
      throw Exception('Failed to load files');
    }
  }
  
  // ==================== Config ====================
  
  Future<Map<String, String?>> getConfig() async {
    final response = await http.get(Uri.parse('$baseUrl/api/config'));
    
    if (response.statusCode == 200) {
      Map<String, dynamic> data = json.decode(response.body);
      return {
        'groq_api_key': data['groq_api_key'],
        'gemini_api_key': data['gemini_api_key'],
      };
    } else {
      throw Exception('Failed to load config');
    }
  }
  
  Future<void> updateConfig({String? groqKey, String? geminiKey}) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/config'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        if (groqKey != null) 'groq_api_key': groqKey,
        if (geminiKey != null) 'gemini_api_key': geminiKey,
      }),
    );
    
    if (response.statusCode != 200) {
      throw Exception('Failed to update config');
    }
  }
}

// ==================== Models ====================

class Space {
  final String id;
  final String name;
  final String createdAt;
  final int fileCount;
  
  Space({
    required this.id,
    required this.name,
    required this.createdAt,
    required this.fileCount,
  });
  
  factory Space.fromJson(Map<String, dynamic> json) {
    return Space(
      id: json['id'],
      name: json['name'],
      createdAt: json['created_at'],
      fileCount: json['file_count'],
    );
  }
}

class ChatInfo {
  final String id;
  final String title;
  final String preview;
  final String createdAt;
  final String updatedAt;
  final int messageCount;
  
  ChatInfo({
    required this.id,
    required this.title,
    required this.preview,
    required this.createdAt,
    required this.updatedAt,
    required this.messageCount,
  });
  
  factory ChatInfo.fromJson(Map<String, dynamic> json) {
    return ChatInfo(
      id: json['id'],
      title: json['title'],
      preview: json['preview'],
      createdAt: json['created_at'],
      updatedAt: json['updated_at'],
      messageCount: json['message_count'],
    );
  }
}

class Chat {
  final String id;
  final List<ChatMessage> messages;
  final String createdAt;
  final String updatedAt;
  
  Chat({
    required this.id,
    required this.messages,
    required this.createdAt,
    required this.updatedAt,
  });
  
  factory Chat.fromJson(Map<String, dynamic> json) {
    return Chat(
      id: json['id'],
      messages: (json['messages'] as List)
          .map((m) => ChatMessage.fromJson(m))
          .toList(),
      createdAt: json['created_at'],
      updatedAt: json['updated_at'],
    );
  }
}

class ChatMessage {
  final String role;
  final String content;
  final String timestamp;
  
  ChatMessage({
    required this.role,
    required this.content,
    required this.timestamp,
  });
  
  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    return ChatMessage(
      role: json['role'],
      content: json['content'],
      timestamp: json['timestamp'],
    );
  }
}

class ChatResponse {
  final String response;
  final List<dynamic> sources;
  final String chatId;
  final String timestamp;
  
  ChatResponse({
    required this.response,
    required this.sources,
    required this.chatId,
    required this.timestamp,
  });
  
  factory ChatResponse.fromJson(Map<String, dynamic> json) {
    return ChatResponse(
      response: json['response'],
      sources: json['sources'],
      chatId: json['chat_id'],
      timestamp: json['timestamp'],
    );
  }
}
